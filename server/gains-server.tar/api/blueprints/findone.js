module.exports = require('sails-generate-ember-blueprints/templates/basic/api/blueprints/findone.js');
