module.exports = require('sails-generate-ember-blueprints/templates/basic/api/services/Ember.js');
